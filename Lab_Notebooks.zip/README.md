# Lab Notebooks: Big Data Analytics (9) + Machine Learning (10)

## How to run
1. Install Python 3 and Jupyter (e.g. Anaconda). Needed packages: numpy, pandas, matplotlib, seaborn, scikit-learn (all included in Anaconda).
2. Unzip this folder, open a terminal inside it and run `jupyter notebook`.
3. Open any `.ipynb` and choose **Kernel -> Restart & Run All**.

No dataset files, no internet, no Hadoop / MongoDB / Spark / pgmpy / Bokeh installs are needed. Every dataset is generated or embedded inside the notebook (fixed random seeds).

## Notes
- Hadoop (EX2, EX9), MongoDB (EX4, EX5, EX9) and Spark (EX8) notebooks are labelled **LOCAL PYTHON IMPLEMENTATION**: they perform the same operations with plain Python.
- ML EX7 uses a NumPy implementation of a Bayesian network (MLE + variable elimination) instead of pgmpy; ML EX10 plots with Matplotlib instead of Bokeh.
- Datasets that are not public inside scikit-learn (crime, wine, Pima diabetes, Cleveland heart) are synthetic stand-ins with the same columns/shape, so exact numbers differ from the PDF where the PDF used the real file.
